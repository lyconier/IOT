<?php
namespace app\index\validate;
use think\Validate;
class Submit extends Validate{
	//规则
	protected $rule=[
		['submit_content','require|token','提交内容不能为空|请勿重复提交'],
		['submit_date','require','提交日期不能为空'],
		['task_id','require|integer','作业ID必须|作业ID必须为整数'],
		['stu_id','require|integer','学生ID必须|学生ID必须为整数'],
	];
	//验证场景
	protected $scene=[
			'edit'=>['submit_content','submit_date','task_id','student_id'],
			'add'=>['submit_content','submit_date','task_id','student_id'],
	];
}