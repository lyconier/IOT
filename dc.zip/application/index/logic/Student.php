<?php
namespace app\index\logic;
use think\Model;
use app\index\model\Clas;
class Student extends Model
{
 	//获取学生所在班级的所有作业
	public function getTasks($stuno)
	{
		$stu=$this::get(['stu_no'=>$stuno]);
		$clas=Clas::get(['clas_id'=>$stu['clas_id']]);
		return $clas->task;
	}
}