<?php
namespace app\index\logic;
use think\Model;
class User extends Model
{
    //检查用户是否存在
	public function checkuser($username,$password)
	{
		
	}
}