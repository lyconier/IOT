<?php
namespace app\index\controller;
use think\Controller;
use app\index\model\User as UserModel;
use app\index\model\Student as StuModel;
use app\index\model\Teacher as TeaModel;
use think\Session;
class Account extends Controller
{
	public function login()
	{
		return $this->fetch();

	}
	public function dologin()
	{
		$kind=$_POST['kind'];
		if($kind=='tea')
		{
			$teacher=TeaModel::get(['username'=>$_POST['username'],'password'=>md5($_POST['pwd'])]);
			if($teacher)
			{
				
					echo '教师登陆成功';
				
			}else 
			
			{   
				$this->error('用户名或密码错误');
			}
			
		}else 
		{
			$stu=StuModel::get(['stu_no'=>$_POST['username'],'password'=>md5($_POST['pwd'])]);
			if($stu)
			{
				//$_SESSION['stuno']=$stu->stu_no;
				Session::set('stuno',$stu->stu_no);
				$this->success('登陆成功','Student/'.$stu->stu_no);
			}
			else 
			{
				$this->error('用户名或密码错误');
			}
		}
	}
}