<?php
namespace app\index\controller;
use think\Controller;
use app\index\model\Student as StuModel;
use app\index\model\Task as TaskModel;
use app\index\model\Submit as SubmitModel;
use think\Request;//用于Session读取
class Student extends Controller{
	public function _initialize()
	{
		 $request=new Request();
		//初始化的时候检查 用户权限
		if(null==$request->session('stuno')||$request->session('stuno')=='')
		{
			
			$this->error("您没有该页的访问权限！","Account/login");
			
			exit;
			
		}else 
		{
			$stuno=$request->session('stuno');
			$stu=StuModel::get(['stu_no'=>$stuno]);
			$this->assign('stuid',$stu['stu_id']);
			$this->assign('stuname',$stu['stu_name']);
			//左侧默认无active菜单
			$this->assign('index','');
			$this->assign('faq','');
			
		}
	}
	public function index($stuno)
	{
		
		$this->view->engine->layout('userlayout');
		$this->assign('index','active');
		
		return $this->fetch();
		//echo "欢迎登陆学生界面 ".$stu->stu_name;
	}
	
	//交作业界面
	public function submittask($taskid)
	{
		$task=TaskModel::get(['task_id'=>$taskid]);
		$this->assign('task',$task);
		$this->view->engine->layout('userlayout');
		return $this->fetch();
	}
	
	//交作业处理过程
	public function dosubmittask()
	{
		$data=input('post.');
		// 数据验证
		$result=$this->validate($data,'Submit');
		if(true!==$result)
		{
			return $result;
		}
		$sub=new SubmitModel;
		//数据保存
		$user->allowField(true)->save($data);
		return '作业'.$sub->submit_id.'提交成功';
	}
	
	public function faq(Request $request)
	{
		$this->assign('faq','active');
		$this->view->engine->layout('userlayout');
		$stulogic=\think\Loader::model('Student','logic');
		$stuno=$request->session('stuno');
		$tasklist=$stulogic->getTasks($stuno);
		$this->assign('tasklist',$tasklist);
		return $this->fetch();
	}
	public function account()
	{
		$this->view->engine->layout('userlayout');
		return $this->fetch();
	}
}