<?php
namespace app\index\service;
use think\Model;
class User extends Model{
	
}