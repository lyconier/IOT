<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:58:"E:\xampp\htdocs\dc/application/index\view\student\faq.html";i:1477626365;s:57:"E:\xampp\htdocs\dc/application/index\view\userlayout.html";i:1477468171;}*/ ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>欢迎使用 DC 学生作业管理系统</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="../../public/static/vendor/matrix-admin/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../../public/static/vendor/matrix-admin/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet" />
    <link href="../../public/static/vendor/matrix-admin/css/font-awesome.css" rel="stylesheet" />
    
    <link href="../../public/static/vendor/matrix-admin/css/adminia.css" rel="stylesheet" /> 
    <link href="../../public/static/vendor/matrix-admin/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="../../public/static/vendor/matrix-admin/css/pages/dashboard.css" rel="stylesheet" /> 
    

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>

<body>
	
<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="./">DC 学生作业管理系统</a>
			
			<div class="nav-collapse">
			
				<ul class="nav pull-right">
					<li>
						<a href="#"><span class="badge badge-warning">7</span></a>
					</li>
					
					<li class="divider-vertical"></li>
					
					<li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							  <?php echo $stuname; ?> <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
							<li>
								<a href="./account.html"><i class="icon-user"></i> Account Setting  </a>
							</li>
							
							<li>
								<a href="./change_password.html"><i class="icon-lock"></i> Change Password</a>
							</li>
							
							<li class="divider"></li>
							
							<li>
								<a href="./"><i class="icon-off"></i> Logout</a>
							</li>
						</ul>
					</li>
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->




<div id="content">
	
	<div class="container">
		
		<div class="row">
			
			<div class="span3">
				
				<div class="account-container">
				
					<div class="account-avatar">
						<img src="../../public/static/vendor/matrix-admin/img/headshot.png" alt="" class="thumbnail" />
					</div> <!-- /account-avatar -->
				
					<div class="account-details">
					
						<span class="account-name"><?php echo $stuname; ?></span>
						
						<span class="account-role">学生</span>
						
						<span class="account-actions">
							<a href="javascript:;">Profile</a> |
							
							<a href="javascript:;">Edit Settings</a>
						</span>
					
					</div> <!-- /account-details -->
				
				</div> <!-- /account-container -->
				
				<hr />
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
					
					<li class="<?php echo $index; ?>">
						<a href="./<?php echo \think\Request::instance()->session('stuno'); ?>.html">
							<i class="icon-home"></i>
							已完成作业 		
						</a>
					</li>
					
					<li class="<?php echo $faq; ?>">
						<a href="./faq.html">
							<i class="icon-pushpin"></i>
							未完成作业	
						</a>
					</li>
					
					<li>
						<a href="./plans.html">
							<i class="icon-th-list"></i>
							Pricing Plans		
						</a>
					</li>
					
					<li>
						<a href="./grid.html">
							<i class="icon-th-large"></i>
							Grid Layout	
							<span class="label label-warning pull-right">5</span>
						</a>
					</li>
					
					<li>
						<a href="./charts.html">
							<i class="icon-signal"></i>
							Charts	
						</a>
					</li>
					
					<li>
						<a href="./account.html">
							<i class="icon-user"></i>
							User Account							
						</a>
					</li>
					
					<li>
						<a href="./login.html">
							<i class="icon-lock"></i>
							Login	
						</a>
					</li>
					
				</ul>	
				
				<hr />
				
				<div class="sidebar-extra">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.</p>
				</div> <!-- .sidebar-extra -->
				
				<br />
		
			</div> <!-- /span3 -->
			
			
			<div class="span9">
				<link href="../../public/static/vendor/matrix-admin/css/pages/faq.css" rel="stylesheet" /> 
	<h1 class="page-title">
					<i class="icon-pushpin"></i>
					作业列表					
				</h1>
				
				<div class="widget">
														
					<div class="widget-content">
						
						<h3>Search...</h3>
									
						
						<ol class="faq-list">
						<?php if(is_array($tasklist) || $tasklist instanceof \think\Collection): $i = 0; $__LIST__ = $tasklist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$task): $mod = ($i % 2 );++$i;?>
							<li>
									<h4><?php echo $task['task_title']; ?></h4>
									<p><?php echo $task['task_content']; ?></p>	
									<p>布置时间：<?php echo $task['submit_date']; ?></p>
									<p>截至日期：<?php echo $task['finish_date']; ?></p>
									<?php if($task['finish_date']>date('Y-m-d',time())): ?>
									<p><a href="./<?php echo $task['task_id']; ?>.html">交作业</a></p>
									<?php else: ?><p style="color:red;">已过期</p>
									<?php endif; ?>
							 </li>
						<?php endforeach; endif; else: echo "" ;endif; ?>
						</ol>
										
					</div> <!-- /widget-content -->
					
				</div> <!-- /widget -->
<script src="../../public/static/vendor/matrix-admin/js/jquery-1.7.2.min.js"></script>
<script src="../../public/static/vendor/matrix-admin/js/bootstrap.js"></script>
<script src="../../public/static/vendor/matrix-admin/js/faq.js"></script>

<script>

$(function () {
	
	$('.faq-list').goFaq ();
	
});

</script>



			</div>
			
		</div> <!-- /row -->
		
	</div> <!-- /container -->
	
</div> <!-- /content -->
					
	
<div id="footer">
	
	<div class="container">				
		<hr />
		<p>&copy; 2012 Go Ideate.</p>
	</div> <!-- /container -->
	
</div> <!-- /footer -->




  </body>
</html>
