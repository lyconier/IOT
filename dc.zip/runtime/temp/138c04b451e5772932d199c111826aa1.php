<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:65:"E:\xampp\htdocs\dc/application/index\view\student\submittask.html";i:1477967402;s:57:"E:\xampp\htdocs\dc/application/index\view\userlayout.html";i:1477468171;}*/ ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>欢迎使用 DC 学生作业管理系统</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />    
    
    <link href="../../public/static/vendor/matrix-admin/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../../public/static/vendor/matrix-admin/css/bootstrap-responsive.min.css" rel="stylesheet" />
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet" />
    <link href="../../public/static/vendor/matrix-admin/css/font-awesome.css" rel="stylesheet" />
    
    <link href="../../public/static/vendor/matrix-admin/css/adminia.css" rel="stylesheet" /> 
    <link href="../../public/static/vendor/matrix-admin/css/adminia-responsive.css" rel="stylesheet" /> 
    
    <link href="../../public/static/vendor/matrix-admin/css/pages/dashboard.css" rel="stylesheet" /> 
    

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>

<body>
	
<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 
				<span class="icon-bar"></span> 				
			</a>
			
			<a class="brand" href="./">DC 学生作业管理系统</a>
			
			<div class="nav-collapse">
			
				<ul class="nav pull-right">
					<li>
						<a href="#"><span class="badge badge-warning">7</span></a>
					</li>
					
					<li class="divider-vertical"></li>
					
					<li class="dropdown">
						
						<a data-toggle="dropdown" class="dropdown-toggle " href="#">
							  <?php echo $stuname; ?> <b class="caret"></b>							
						</a>
						
						<ul class="dropdown-menu">
							<li>
								<a href="./account.html"><i class="icon-user"></i> Account Setting  </a>
							</li>
							
							<li>
								<a href="./change_password.html"><i class="icon-lock"></i> Change Password</a>
							</li>
							
							<li class="divider"></li>
							
							<li>
								<a href="./"><i class="icon-off"></i> Logout</a>
							</li>
						</ul>
					</li>
				</ul>
				
			</div> <!-- /nav-collapse -->
			
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->




<div id="content">
	
	<div class="container">
		
		<div class="row">
			
			<div class="span3">
				
				<div class="account-container">
				
					<div class="account-avatar">
						<img src="../../public/static/vendor/matrix-admin/img/headshot.png" alt="" class="thumbnail" />
					</div> <!-- /account-avatar -->
				
					<div class="account-details">
					
						<span class="account-name"><?php echo $stuname; ?></span>
						
						<span class="account-role">学生</span>
						
						<span class="account-actions">
							<a href="javascript:;">Profile</a> |
							
							<a href="javascript:;">Edit Settings</a>
						</span>
					
					</div> <!-- /account-details -->
				
				</div> <!-- /account-container -->
				
				<hr />
				
				<ul id="main-nav" class="nav nav-tabs nav-stacked">
					
					<li class="<?php echo $index; ?>">
						<a href="./<?php echo \think\Request::instance()->session('stuno'); ?>.html">
							<i class="icon-home"></i>
							已完成作业 		
						</a>
					</li>
					
					<li class="<?php echo $faq; ?>">
						<a href="./faq.html">
							<i class="icon-pushpin"></i>
							未完成作业	
						</a>
					</li>
					
					<li>
						<a href="./plans.html">
							<i class="icon-th-list"></i>
							Pricing Plans		
						</a>
					</li>
					
					<li>
						<a href="./grid.html">
							<i class="icon-th-large"></i>
							Grid Layout	
							<span class="label label-warning pull-right">5</span>
						</a>
					</li>
					
					<li>
						<a href="./charts.html">
							<i class="icon-signal"></i>
							Charts	
						</a>
					</li>
					
					<li>
						<a href="./account.html">
							<i class="icon-user"></i>
							User Account							
						</a>
					</li>
					
					<li>
						<a href="./login.html">
							<i class="icon-lock"></i>
							Login	
						</a>
					</li>
					
				</ul>	
				
				<hr />
				
				<div class="sidebar-extra">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.</p>
				</div> <!-- .sidebar-extra -->
				
				<br />
		
			</div> <!-- /span3 -->
			
			
			<div class="span9">
				
<div class="row">
					
					<div class="span9">
				
						<div class="widget">
									
							<div class="widget-content">
								
								<h3><?php echo $task['task_title']; ?></h3>
								
								<p><?php echo $task['task_content']; ?></p>
							 <form id="submit-form" name="submit-form" action="<?php echo url('index/student/dosubmittask'); ?>" method="post"/>
									<fieldset>
										<div class="control-group">											
											<label class="control-label" for="submit-content">答题区</label>
											<div class="controls">
												<textarea  class="input-medium" id="submit_content" name="submit_content" style="width:700px;height:300px;"></textarea>
												<?php echo token(); ?>
												<input type="hidden" name="task_id" value=<?php echo $task['task_id']; ?>/>
												<input type="hidden" name="stu_id" value=<?php echo $stuid; ?>/>
												<p class="help-block">
													<ul>
														<li>附件请压缩成rar格式或zip格式后上传</li> 
														<li>ctrl+enter快速提交</li>
													</ul>
												</p>
											</div> <!-- /controls -->				
										</div> <!-- /control-group -->
										<br />
										<div class="form-actions">
											<button type="submit" class="btn btn-primary">提 交</button> 
											<button class="btn">取 消</button>
										</div> <!-- /form-actions -->
									</fieldset>
							</form>	
							</div> <!-- /widget-content -->
							
							
						</div> <!-- /widget -->
						
					</div> <!-- /span9 -->
					
</div> <!-- /row -->
<link rel="stylesheet" href="../../public/static/vendor/kindeditor/themes/default/default.css" />
	<link rel="stylesheet" href="../../public/static/vendor/kindeditor/plugins/code/prettify.css" />
	<script charset="utf-8" src="../../public/static/vendor/kindeditor/kindeditor.js"></script>
	<script charset="utf-8" src="../../public/static/vendor/kindeditor/lang/zh_CN.js"></script>
	<script charset="utf-8" src="../../public/static/vendor/kindeditor/plugins/code/prettify.js"></script>
	<script>
		KindEditor.ready(function(K) {
			var editor1 = K.create('textarea[name="submit-content"]', {
				cssPath : '../../public/static/vendor/kindeditor/plugins/code/prettify.css',
				uploadJson : '../../public/static/vendor/kindeditor/php/upload_json.php',
				fileManagerJson : '../../public/static/vendor/kindeditor/php/file_manager_json.php',
				allowFileManager : true,
				afterCreate : function() {
					var self = this;
					K.ctrl(document, 13, function() {
						self.sync();
						K('form[name=submit-form]')[0].submit();
					});
					K.ctrl(self.edit.doc, 13, function() {
						self.sync();
						K('form[name=submit-form]')[0].submit();
					});
				}
			});
			prettyPrint();
		});
	</script>
			</div>
			
		</div> <!-- /row -->
		
	</div> <!-- /container -->
	
</div> <!-- /content -->
					
	
<div id="footer">
	
	<div class="container">				
		<hr />
		<p>&copy; 2012 Go Ideate.</p>
	</div> <!-- /container -->
	
</div> <!-- /footer -->




  </body>
</html>
