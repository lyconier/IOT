<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:68:"E:\xampp\htdocs\dc\public/../application/index\view\index\index.html";i:1470727651;s:63:"E:\xampp\htdocs\dc\public/../application/index\view\layout.html";i:1470730767;s:70:"E:\xampp\htdocs\dc\public/../application/index\view\Public\header.html";i:1470729021;s:70:"E:\xampp\htdocs\dc\public/../application/index\view\Public\footer.html";i:1470729726;}*/ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>欢迎使用作业管理系统</title>
<link rel="stylesheet" href="static/css/bootstrap.min.css"/>
<script src="static/js/jquery.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<div class="row">
	<div class="col-md-8">
		<img src="static/imgs/logo.jpg"/>
	</div>
</div>
 !Templates.html5.content!
 </div>
<div class="container">
	<div class="row">
		<div class="col-md-12">
    		© 版权所有  all right reserved!
    	</div>
    </div>
</div>
</body>
</html>