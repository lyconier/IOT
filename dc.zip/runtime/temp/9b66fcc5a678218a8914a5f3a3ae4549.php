<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:58:"E:\xampp\htdocs\dc/application/index\view\index\index.html";i:1470727651;s:53:"E:\xampp\htdocs\dc/application/index\view\layout.html";i:1470818370;s:60:"E:\xampp\htdocs\dc/application/index\view\Public\header.html";i:1474943149;s:60:"E:\xampp\htdocs\dc/application/index\view\Public\footer.html";i:1470818515;}*/ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>欢迎使用作业管理系统</title>
<link rel="stylesheet" href="../public/static/vendor/bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" href="../public/static/css/site.css"/>
<script src="../public/static/js/jquery.min.js"></script>
<script src="../public/static/vendor/bootstrap/js/bootstrap.min.js"></script>

</head>
<body>

<div class="container">
<div class="row" style="margin-bottom:5px;padding-top:10px;">
	<div class="col-md-8">
		<img src="../public/static/imgs/logo.jpg"/>
	</div>
</div>
</div>
<hr/>
<div class="container">
 !Templates.html5.content!
 </div>
 <hr/>
<div class="container">
	<div class="row">
		<div class="col-md-12">
    		© 版权所有  保留所有权利
    	</div>
    </div>
</div>
</body>
</html>