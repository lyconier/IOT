<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:60:"E:\xampp\htdocs\dc/application/index\view\account\login.html";i:1477031784;s:53:"E:\xampp\htdocs\dc/application/index\view\layout.html";i:1470818370;s:60:"E:\xampp\htdocs\dc/application/index\view\Public\header.html";i:1474943149;s:60:"E:\xampp\htdocs\dc/application/index\view\Public\footer.html";i:1476239572;}*/ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>欢迎使用作业管理系统</title>
<link rel="stylesheet" href="../public/static/vendor/bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" href="../public/static/css/site.css"/>
<script src="../public/static/js/jquery.min.js"></script>
<script src="../public/static/vendor/bootstrap/js/bootstrap.min.js"></script>

</head>
<body>

<div class="container">
<div class="row" style="margin-bottom:5px;padding-top:10px;">
	<div class="col-md-8">
		<img src="../public/static/imgs/logo.jpg"/>
	</div>
</div>
</div>
<hr/>
<div class="container">
 <link rel="stylesheet" href="../public/static/vendor/bootstrapvalidator/css/bootstrapValidator.min.css"/>
<script type="text/javascript" src="../public/static/vendor/bootstrapvalidator/js/bootstrapValidator.min.js"></script>
<style>
	.input-group{
		margin:10px 0px;
	}
	
	li{
		list-style-type:square;
		margin:10px 0;
	}
	
</style>
<div class="row" style="margin-top:30px;">

<div class="col-md-6" style="border-right:1px solid #ddd;">
<div class="well col-md-10">
<h3>用户登录</h3>
<div class="row">
<form action="dologin" method="post" id="loginform">
	<div class="form-group">
		<div class="input-group input-group-md">
  			<span class="input-group-addon" id="sizing-addon1"><i class="glyphicon glyphicon-user" aria-hidden="true"></i></span>
  			<input type="text" class="form-control" name="username" placeholder="用户名"  />
		</div>
	</div>
	<div class="form-group">
		<div class="input-group input-group-md">
  			<span class="input-group-addon" id="sizing-addon1"><i class="glyphicon glyphicon-lock"></i></span>
  			<input type="password" class="form-control" name="pwd" placeholder="密码"  />
		</div>
	</div>
	<div class="well well-sm form-group" style="text-align:center;">
		
  			<input type="radio" name="kind" value="tea"> 老师
  			<input type="radio" name="kind" value="stu" checked="checked"> 学生
	</div>
	<button type="submit" class="btn btn-success btn-block">
                                                登录
    </button>
 </form> 
 </div>
</div>
</div>
<div class="col-md-6">
<h3>
欢迎使用学生作业管理系统
</h3>
<ul>
<li>学生使用<em>学号</em>登录，初始密码为<em>6个1</em>，登录后请及时修改密码</li>
<li>老师请使用<em>工号</em>登录，初始密码为<em>6个1</em>，登录后请及时修改密码</li>
</ul>
</div>

</div>
<script type="text/javascript">
$(document).ready(function(){
	  // 在这里写你的代码...
	$('#loginform').bootstrapValidator({
		message:"您的输入值不合法",
		feedbackIcons:{
			valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
		},
		fields:{
			username:{
				validators:{
					notEmpty:{
						message:'用户名不能为空'
					},
					stringLength: {
                        min: 6,
                        max: 30,
                        message: '用户名的长度须在6到30位之间'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z0-9_\.]+$/,
                        message: '用户名中只能包含字母、数字和下划线'
                    },
				}
			},
		 pwd:{
			 validators:{
				 notEmpty:{
					 message:'请输入密码'
				 }
			 }
		 },
		 kind: {
             validators: {
                 notEmpty: {
                     message: '请选择你的身份'
                 }
             }
         },
		},
	});
	});
	
</script>
 </div>
 <hr/>
<div class="container" id="footer">
	<div class="row">
		<div class="col-md-12">
    		© 版权所有  保留所有权利
    	</div>
    </div>
</div>
</body>
</html>